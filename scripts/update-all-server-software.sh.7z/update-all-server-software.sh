#/bin/bash

ansible-playbook --ask-become ../playbooks/update-all-server-software.yml
